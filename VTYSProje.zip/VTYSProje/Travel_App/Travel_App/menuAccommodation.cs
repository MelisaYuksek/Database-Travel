﻿using Npgsql;
using System;
using System.Windows.Forms;

namespace Travel_App
{
    public partial class menuAccommodation : Form
    {
        public menuAccommodation()
        {
            InitializeComponent();
        }

        // Bağlantıyı daha güvenli şekilde tanımlayalım
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=seyahatproje; " +
            "user ID=postgres; password=5847");

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                // Kullanıcıdan gelen verileri kontrol et
                if (string.IsNullOrWhiteSpace(txtUserid.Text) || string.IsNullOrWhiteSpace(txtPaymentid.Text))
                {
                    MessageBox.Show("Please enter valid User ID and Payment ID.");
                    return; // Eğer UserID veya PaymentID girilmemişse işlem yapma
                }

                if (at_combo.Text == "hotel" || at_combo.Text == "hostel")
                {
                    // Bağlantıyı aç
                    baglanti.Open();

                    // SQL komutunu oluştur
                    NpgsqlCommand komut4 = new NpgsqlCommand("INSERT INTO public.accommodation (userid, paymentid, type, date) VALUES (@p1, @p2, @p3, @p4)", baglanti);

                    // Parametreleri ekle
                    komut4.Parameters.AddWithValue("@p1", int.Parse(txtUserid.Text));
                    komut4.Parameters.AddWithValue("@p2", int.Parse(txtPaymentid.Text));
                    komut4.Parameters.AddWithValue("@p3", at_combo.Text);
                    komut4.Parameters.AddWithValue("@p4", dtpAppointmentDate.Value);

                    // SQL sorgusunu çalıştır
                    komut4.ExecuteNonQuery();
                    MessageBox.Show("Accommodation added successfully.");
                }
                else
                {
                    MessageBox.Show("Invalid selection. Please select 'hotel' or 'hostel'.");
                }
            }
            catch (Exception ex)
            {
                // Hata mesajı göster
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                baglanti.Close(); // Bağlantıyı kapat
            }
        }

        private void accommodationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            menuAccommodation accommodation = new menuAccommodation();
            accommodation.ShowDialog();
            accommodation = null;
            this.Show();
        }

        private void menuAccommodation_Load(object sender, EventArgs e)
        {
            // ComboBox'a seçenekleri ekle
            at_combo.Items.Clear(); // Önceki öğeleri temizler (önceki seçimler varsa)
            at_combo.Items.Add("hotel");
            at_combo.Items.Add("hostel");

            // Varsayılan seçim yap
            at_combo.SelectedIndex = 0; // İlk öğeyi (hotel) varsayılan olarak seçer

            // Kullanıcı girişini engelle (sadece listeden seçim yapılabilir)
            at_combo.DropDownStyle = ComboBoxStyle.DropDownList;
        }
    }
}
