﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace Travel_App
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();
        }

        private void adminBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
           adminMain adminMain = new adminMain();
            adminMain.ShowDialog();
            adminMain = null;
            this.Show();


        }

        private void regularBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            regularMain regularMain = new regularMain();
            regularMain.ShowDialog();
            regularMain = null;
            this.Show();
        }
    }
}
